package com.example.mayaassistant

import android.os.Bundle
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService

class MayaSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = MayaSession(this)
}

class MayaSession(service: MayaSessionService) : VoiceInteractionSession(service) {

    override fun onRequestCommand(request: CommandRequest) {
        val spoken = request.command.orEmpty().trim()
        if (spoken.isEmpty()) {
            request.sendResult(Bundle().apply { putString("response", "কী করতে হবে বলো।") })
            return
        }

        val result = AssistantCore.handle(this, spoken)
        try { result.action?.invoke() } catch (_: Exception) {}

        request.sendResult(Bundle().apply {
            putString("response", result.reply)
        })
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
    }
}
